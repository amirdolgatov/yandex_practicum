// https://contest.yandex.ru/contest/22781/run-report/166151508/

#include <iostream>
#include <vector>

/*
-- ПРИНЦИП РАБОТЫ --

Реализован дек, на основе std::vector.
Поскольку размер известен заранее, то возможно использование
кольцевого буфера в памяти std::vector.
Произведена доработка реализации очереди.
В отличии от очереди итератор head, теперь движется и вперед (push_front),
а итератор tail может двигаться и назад (pop_back). 

-- ДОКАЗАТЕЛЬСТВО КОРРЕКТНОСТИ --

Размер известине заранее , память предвыделяется, переполнения не должно быть.
Во избежания перезаписи данных или некорреткного извлечения, всегда контроллируется размер 
дека

-- ВРЕМЕННАЯ СЛОЖНОСТЬ --

Все операции это операции с непрерывным массивом памяти, с известными адресами для извлечения 
и добавления элементов. Все операции имеют сложность O(1).

-- ПРОСТРАНСТВЕННАЯ СЛОЖНОСТЬ --

Объем требуемой памяти фиксирован и известен заранее, пространственная сложность O(n).
*/

class Deque
{
private:

	std::vector<int> queue;

    /* итераторы */
    int head_pop;
    int head_push;
    int tail_pop;
    int tail_push;

    int max_n;
    int size;

public:

	Deque(int n) 
	{
        queue.resize(n);

        head_pop = 0;
        head_push = 0;
        tail_pop = 0;
        tail_push = 0;

        max_n = n;
        size = 0;
     }

    bool is_empty() 
    {
        return size == 0;
    }

    bool push_back(int x) 
    {
        if (size != max_n) 
        {
            queue[tail_push] = x;
            tail_pop = tail_push;
            tail_push = (tail_push + 1) % max_n;

            if (size == 0)
            {
                head_push = (head_push - 1 + max_n) % max_n;
            }

            size += 1;
            return true;
        }
        return false;
    }

    bool push_front(int x) 
    {
        if (size != max_n) 
        {
            queue[head_push] = x;
            head_pop = head_push;
            head_push = (head_push - 1 + max_n) % max_n; // step back

            if (size == 0)
            {
                tail_push = (tail_push + 1) % max_n;
            }

            size += 1;
            return true;
        }
        return false;
    }

    void pop_back() 
    {
        tail_push = tail_pop;
        size -= 1;

        if (size)
        {
            tail_pop = (tail_pop - 1 + max_n) % max_n;
        }
        else
        {
            head_pop = head_push = tail_pop;
        }
    }

    void pop_front() 
    {
        head_push = head_pop;
        size -= 1;

        if (size)
        {
            head_pop = (head_pop + 1) % max_n;
        }
        else
        {
            tail_push = tail_pop = head_pop;
        }
    }

    int *back()
    {
    	// std::cout << "tail " << tail_pop << '\n';
    	if (is_empty()) 
        {
            return nullptr;
        }
        return &queue[tail_pop];
    }

    int *front()
    {
    	// std::cout << "head " << head_pop << '\n';
    	if (is_empty()) 
        {
            return nullptr;
        }
        return &queue[head_pop];
    }
}; 

int main(void)
{
	int n, m;
    std::cin >> n;
    std::cin >> m;

    Deque deque(m);
    std::string cmd;
    int x;
    bool error = true;

    while (n--) 
    {
        std::cin >> cmd;

        if (cmd == "push_back") 
        {
            std::cin >> x;
            error = !(deque.push_back(x));
        } 
        if (cmd == "push_front") 
        {
            std::cin >> x;
            error = !(deque.push_front(x));
        } 
        else if (cmd == "pop_back") 
        {
        	int *data_ptr = deque.back();
        	if (data_ptr == nullptr)
        	{
        		error = true;
        	}
        	else
        	{
        		std::cout << *data_ptr << '\n';
        		deque.pop_back();
        		error = false;
        	}
        } 
        else if (cmd == "pop_front") 
        {
            int *data_ptr = deque.front();
        	if (data_ptr == nullptr)
        	{
        		error = true;
        	}
        	else
        	{
        		std::cout << *data_ptr << '\n';
        		deque.pop_front();
        		error = false;
        	}
        }

        if (error)
        {
        	std::cout << "error\n";
        }
    }

	return 0;
}